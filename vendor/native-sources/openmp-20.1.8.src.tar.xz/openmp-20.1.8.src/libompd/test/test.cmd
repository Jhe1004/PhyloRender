ompd init
continue
quit